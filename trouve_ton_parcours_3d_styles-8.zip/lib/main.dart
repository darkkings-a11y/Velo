import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const AppVelo());
}

class AppVelo extends StatelessWidget {
  const AppVelo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TotoPa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

