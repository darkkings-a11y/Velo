import 'package:latlong2/latlong.dart';

/// Une ville traversée par le parcours.
class EtapeVille {
  final String nom;
  final LatLng position;
  final double distanceKm; // distance depuis le départ

  const EtapeVille({
    required this.nom,
    required this.position,
    required this.distanceKm,
  });
}

/// Une portion du parcours entre deux villes.
class TronconParcours {
  final String depart;
  final String arrivee;
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;

  const TronconParcours({
    required this.depart,
    required this.arrivee,
    required this.distanceKm,
    required this.denivelePos,
    required this.deniveleNeg,
  });
}

class Parcours {
  static const String sourceOfficielle = 'GPX Officiel';
  static const String sourceAuto = 'Généré auto';
  static const String sourceImport = 'Importé';
  static const String sourceOpenData = 'OpenStreetMap';

  final String titre;
  final String distance;
  final String duree;
  final String difficulte;
  final String ville;
  final String denivele; // ex: "450 m D+"
  final List<LatLng> traceGPS;

  // Données détaillées (optionnelles pour rester compatible)
  final List<double> altitudes; // une altitude par point de traceGPS
  final List<double> distancesKm; // distance cumulée (km) par point
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;
  final List<EtapeVille> etapes;
  final List<TronconParcours> troncons;

  // Provenance et popularité
  final String source; // sourceOfficielle, sourceAuto ou sourceImport
  final bool verifie; // parcours vérifié / recommandé
  final int popularite; // nombre de consultations (sert au tri)
  final String detailSource; // ex. « itinéraire régional » pour un tracé OpenStreetMap

  bool get estRecommande => verifie && source == sourceOfficielle;
  bool get estOpenData => source == sourceOpenData;

  const Parcours({
    required this.titre,
    required this.distance,
    required this.duree,
    required this.difficulte,
    required this.ville,
    required this.denivele,
    required this.traceGPS,
    this.altitudes = const [],
    this.distancesKm = const [],
    this.distanceKm = 0,
    this.denivelePos = 0,
    this.deniveleNeg = 0,
    this.etapes = const [],
    this.troncons = const [],
    this.source = sourceAuto,
    this.verifie = false,
    this.popularite = 0,
    this.detailSource = '',
  });

  /// Identifiant stable pour retrouver un parcours dans les favoris.
  String get id =>
      '${titre}_${distanceKm.toStringAsFixed(2)}_${traceGPS.isNotEmpty ? traceGPS.first.latitude.toStringAsFixed(4) : ''}';

  Map<String, dynamic> toJson() => {
        'titre': titre,
        'distance': distance,
        'duree': duree,
        'difficulte': difficulte,
        'ville': ville,
        'denivele': denivele,
        'trace': traceGPS
            .map((p) => [
                  double.parse(p.latitude.toStringAsFixed(5)),
                  double.parse(p.longitude.toStringAsFixed(5)),
                ])
            .toList(),
        'altitudes': altitudes.map((a) => double.parse(a.toStringAsFixed(1))).toList(),
        'distancesKm': distancesKm.map((d) => double.parse(d.toStringAsFixed(3))).toList(),
        'distanceKm': distanceKm,
        'denivelePos': denivelePos,
        'deniveleNeg': deniveleNeg,
        'etapes': etapes
            .map((e) => {
                  'nom': e.nom,
                  'lat': e.position.latitude,
                  'lon': e.position.longitude,
                  'km': e.distanceKm,
                })
            .toList(),
        'source': source,
        'verifie': verifie,
        'popularite': popularite,
        'detailSource': detailSource,
        'troncons': troncons
            .map((t) => {
                  'depart': t.depart,
                  'arrivee': t.arrivee,
                  'km': t.distanceKm,
                  'dp': t.denivelePos,
                  'dn': t.deniveleNeg,
                })
            .toList(),
      };

  factory Parcours.fromJson(Map<String, dynamic> j) {
    return Parcours(
      source: (j['source'] as String?) ?? sourceAuto,
      verifie: (j['verifie'] as bool?) ?? false,
      popularite: (j['popularite'] as num?)?.toInt() ?? 0,
      detailSource: (j['detailSource'] as String?) ?? '',
      titre: j['titre'] as String,
      distance: j['distance'] as String,
      duree: j['duree'] as String,
      difficulte: j['difficulte'] as String,
      ville: j['ville'] as String,
      denivele: j['denivele'] as String,
      traceGPS: (j['trace'] as List)
          .map((p) => LatLng((p[0] as num).toDouble(), (p[1] as num).toDouble()))
          .toList(),
      altitudes: (j['altitudes'] as List).map((a) => (a as num).toDouble()).toList(),
      distancesKm: (j['distancesKm'] as List).map((d) => (d as num).toDouble()).toList(),
      distanceKm: (j['distanceKm'] as num).toDouble(),
      denivelePos: (j['denivelePos'] as num).toInt(),
      deniveleNeg: (j['deniveleNeg'] as num).toInt(),
      etapes: (j['etapes'] as List)
          .map((e) => EtapeVille(
                nom: e['nom'] as String,
                position: LatLng((e['lat'] as num).toDouble(), (e['lon'] as num).toDouble()),
                distanceKm: (e['km'] as num).toDouble(),
              ))
          .toList(),
      troncons: (j['troncons'] as List)
          .map((t) => TronconParcours(
                depart: t['depart'] as String,
                arrivee: t['arrivee'] as String,
                distanceKm: (t['km'] as num).toDouble(),
                denivelePos: (t['dp'] as num).toInt(),
                deniveleNeg: (t['dn'] as num).toInt(),
              ))
          .toList(),
    );
  }
}
