import 'package:flutter/material.dart';
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../widgets/import_gpx.dart';
import 'carte_screen.dart';

class FavorisScreen extends StatefulWidget {
  const FavorisScreen({super.key});

  @override
  State<FavorisScreen> createState() => _FavorisScreenState();
}

class _FavorisScreenState extends State<FavorisScreen> {
  List<Parcours>? _favoris;

  @override
  void initState() {
    super.initState();
    _recharger();
  }

  Future<void> _recharger() async {
    final liste = await FavorisService.charger();
    if (mounted) setState(() => _favoris = liste);
  }

  @override
  Widget build(BuildContext context) {
    final favoris = _favoris;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes parcours favoris'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Importer un fichier GPX',
            onPressed: () async {
              await importerGpx(context);
              _recharger();
            },
          ),
        ],
      ),
      body: favoris == null
          ? const Center(child: CircularProgressIndicator())
          : favoris.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.favorite_border, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'Aucun favori pour le moment.',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Appuie sur le ❤ d\'un parcours, ou importe un fichier GPX avec le bouton en haut.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: favoris.length,
                  itemBuilder: (context, index) {
                    final p = favoris[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        leading: const Icon(Icons.directions_bike, color: Colors.green),
                        title: Text(p.titre),
                        subtitle: Text('${p.distance}  |  +${p.denivelePos} m / -${p.deniveleNeg} m'),
                        trailing: IconButton(
                          icon: const Icon(Icons.favorite, color: Colors.redAccent),
                          tooltip: 'Retirer des favoris',
                          onPressed: () async {
                            await FavorisService.retirer(p);
                            _recharger();
                          },
                        ),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => CarteScreen(parcours: p)),
                          );
                          _recharger();
                        },
                      ),
                    );
                  },
                ),
    );
  }
}
