import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'gpx_service.dart';
import 'popularite_service.dart';

class _Entree {
  final String fichier;
  final String? titre;
  final String? style; // route, balade, vtt ; null = tous les styles
  final int popularite;
  final bool verifie;
  final String source;
  final double? lat;
  final double? lon;
  final double? km;

  _Entree(Map<String, dynamic> j)
      : fichier = j['fichier'] as String,
        titre = j['titre'] as String?,
        style = j['style'] as String?,
        popularite = (j['popularite'] as num?)?.toInt() ?? 0,
        verifie = (j['verifie'] as bool?) ?? true,
        source = (j['source'] as String?) ?? Parcours.sourceOfficielle,
        lat = (j['lat'] as num?)?.toDouble(),
        lon = (j['lon'] as num?)?.toDouble(),
        km = (j['km'] as num?)?.toDouble();
}

/// Les GPX recommandés, livrés avec l'application dans `assets/gpx/` (liste dans `assets/gpx/index.json`).
class BaseGpxService {
  static const String _dossier = 'assets/gpx/';
  static final Distance _calc = Distance(roundResult: false);

  static List<_Entree>? _index;
  static final Map<String, ({LatLng depart, double km})?> _resumes = {};

  /// GPX recommandés près de [centre], pour le style demandé, de longueur proche de [distanceKm],
  /// triés par popularité (les plus consultés d'abord).
  static Future<List<Parcours>> pourVille({
    required LatLng centre,
    required String profil,
    required int distanceKm,
    double rayonKm = 30,
    double tolerance = 0.35,
  }) async {
    try {
      final index = await _chargerIndex();
      if (index.isEmpty) return [];

      final retenues = <_Entree>[];
      for (final e in index) {
        if (e.style != null && e.style != profil) continue;
        LatLng? depart = (e.lat != null && e.lon != null) ? LatLng(e.lat!, e.lon!) : null;
        double? km = e.km;
        if (depart == null || km == null) {
          final r = await _resume(e.fichier);
          if (r == null) continue;
          depart ??= r.depart;
          km ??= r.km;
        }
        final dep = depart!;
        final longueur = km!;
        if (_calc.as(LengthUnit.Kilometer, centre, dep) > rayonKm) continue;
        if ((longueur - distanceKm).abs() > distanceKm * tolerance) continue;
        retenues.add(e);
      }
      if (retenues.isEmpty) return [];

      final vues = await PopulariteService.charger();
      final lus = await Future.wait(retenues.map((e) async {
        try {
          final octets = (await rootBundle.load('$_dossier${e.fichier}')).buffer.asUint8List();
          final p = await GpxService.lire(
            octets,
            nomFichier: e.fichier,
            titre: e.titre,
            source: e.source,
            verifie: e.verifie,
            popularite: e.popularite,
          );
          // popularité affichée = valeur de départ + consultations sur ce téléphone
          return GpxService.avecPopularite(p, e.popularite + (vues[p.id] ?? 0));
        } catch (_) {
          return null;
        }
      }));
      final liste = lus.whereType<Parcours>().toList()
        ..sort((a, b) => b.popularite.compareTo(a.popularite));
      return liste;
    } catch (_) {
      return [];
    }
  }

  static Future<List<_Entree>> _chargerIndex() async {
    final deja = _index;
    if (deja != null) return deja;
    try {
      final texte = await rootBundle.loadString('${_dossier}index.json');
      final liste = (json.decode(texte) as List).whereType<Map<String, dynamic>>();
      final res = <_Entree>[];
      for (final j in liste) {
        try {
          res.add(_Entree(j));
        } catch (_) {
          // entrée mal écrite : ignorée
        }
      }
      return _index = res;
    } catch (_) {
      return _index = [];
    }
  }

  static Future<({LatLng depart, double km})?> _resume(String fichier) async {
    if (_resumes.containsKey(fichier)) return _resumes[fichier];
    try {
      final octets = (await rootBundle.load('$_dossier$fichier')).buffer.asUint8List();
      return _resumes[fichier] = GpxService.resume(octets);
    } catch (_) {
      return _resumes[fichier] = null;
    }
  }
}
