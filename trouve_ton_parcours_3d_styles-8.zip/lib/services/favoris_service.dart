import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/parcours.dart';

/// Sauvegarde des parcours favoris sur le téléphone.
class FavorisService {
  static const String _cle = 'favoris_parcours';

  static Future<List<Parcours>> charger() async {
    final prefs = await SharedPreferences.getInstance();
    final brut = prefs.getStringList(_cle) ?? [];
    final liste = <Parcours>[];
    for (final s in brut) {
      try {
        liste.add(Parcours.fromJson(json.decode(s) as Map<String, dynamic>));
      } catch (_) {
        // favori illisible : on l'ignore
      }
    }
    return liste;
  }

  static Future<bool> estFavori(Parcours p) async {
    final liste = await charger();
    return liste.any((f) => f.id == p.id);
  }

  static Future<void> ajouter(Parcours p) async {
    final liste = await charger();
    if (liste.any((f) => f.id == p.id)) return;
    liste.insert(0, p);
    await _sauver(liste);
  }

  static Future<void> retirer(Parcours p) async {
    final liste = await charger();
    liste.removeWhere((f) => f.id == p.id);
    await _sauver(liste);
  }

  static Future<void> _sauver(List<Parcours> liste) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_cle, liste.map((p) => json.encode(p.toJson())).toList());
  }
}
