
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class GeocodingService {
  /// Interroge la Géoplateforme (data.geopf.fr) pour trouver les coordonnées GPS d'une ville ou d'un code postal.
  static Future<LatLng?> recupererCoordonnees(String query) async {
    if (query.trim().isEmpty) return null;

    final url = Uri.parse(
      'https://data.geopf.fr/geocodage/search/?q=${Uri.encodeComponent(query)}&limit=1',
    );

    try {
      // Ajout d'un timeout de 10 secondes pour débloquer l'application rapidement
      final response = await http.get(
        url,
        headers: {
          'User-Agent': 'AppVeloMobile/1.0',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final features = data['features'] as List;

        if (features.isNotEmpty) {
          final coords = features[0]['geometry']['coordinates'] as List;
          double longitude = coords[0];
          double latitude = coords[1];
          return LatLng(latitude, longitude);
        } else {
          throw 'Aucun résultat trouvé pour cette ville.';
        }
      } else {
        throw 'Erreur HTTP : ${response.statusCode}';
      }
    } catch (e) {
      // Annule le chargement et renvoie l'erreur immédiatement au bout de 10s max
      throw 'Erreur réseau ou délai dépassé : $e';
    }
  }
}