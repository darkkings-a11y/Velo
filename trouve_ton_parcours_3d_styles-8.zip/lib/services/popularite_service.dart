import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/parcours.dart';

/// Nombre de consultations de chaque parcours recommandé, sur ce téléphone.
/// (Une popularité partagée entre tous les utilisateurs demanderait un serveur.)
class PopulariteService {
  static const String _cle = 'vues_parcours_recommandes';

  static Future<Map<String, int>> charger() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final brut = prefs.getString(_cle);
      if (brut == null) return {};
      return (json.decode(brut) as Map).map((k, v) => MapEntry(k as String, (v as num).toInt()));
    } catch (_) {
      return {};
    }
  }

  /// À appeler quand l'utilisateur ouvre un parcours recommandé.
  static Future<void> compter(Parcours p) async {
    if (p.source != Parcours.sourceOfficielle) return;
    try {
      final vues = await charger();
      vues[p.id] = (vues[p.id] ?? 0) + 1;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cle, json.encode(vues));
    } catch (_) {}
  }
}
