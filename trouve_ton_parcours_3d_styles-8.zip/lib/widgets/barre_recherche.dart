import 'package:flutter/material.dart';

class BarreRecherche extends StatelessWidget {
  final TextEditingController villeController;
  final int distanceChoisie;
  final ValueChanged<int?> onDistanceChanged;
  final VoidCallback onRechercher;
  final bool isLoading;

  const BarreRecherche({
    super.key,
    required this.villeController,
    required this.distanceChoisie,
    required this.onDistanceChanged,
    required this.onRechercher,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Champ de texte pour la ville ou le code postal
            TextField(
              controller: villeController,
              decoration: const InputDecoration(
                labelText: 'Ville ou code postal de départ',
                hintText: 'Ex: Lyon, Paris, Oullins...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
            ),
            const SizedBox(height: 16),

            // Sélecteur de distance (Dropdown)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Distance de la boucle :',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                DropdownButton<int>(
                  value: distanceChoisie,
                  items: [20, 30, 50, 80].map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: onDistanceChanged,
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Bouton de lancement de la recherche
            ElevatedButton.icon(
              onPressed: isLoading ? null : onRechercher,
              icon: isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.directions_bike),
              label: Text(isLoading ? 'Génération en cours...' : 'Trouver un parcours'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
