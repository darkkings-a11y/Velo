import 'package:flutter/material.dart';

class ParcoursCard extends StatelessWidget {
  final String distance;
  final String denivele;
  final int nbPoints;
  final VoidCallback onVoirCarte;
  final bool recommande; // GPX vérifié de ta base
  final bool balise; // itinéraire réel balisé (OpenStreetMap)
  final String detail; // ex. « itinéraire régional »
  final int popularite;

  const ParcoursCard({
    super.key,
    required this.distance,
    required this.denivele,
    required this.nbPoints,
    required this.onVoirCarte,
    this.recommande = false,
    this.balise = false,
    this.detail = '',
    this.popularite = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  recommande ? Icons.verified : (balise ? Icons.alt_route : Icons.auto_awesome),
                  color: recommande ? Colors.amber : (balise ? Colors.lightBlueAccent : Colors.grey),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    recommande
                        ? 'Recommandé'
                        : (balise ? 'Itinéraire réel${detail.isNotEmpty ? ' · $detail' : ''}' : 'Généré à la volée'),
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: recommande ? Colors.amber : (balise ? Colors.lightBlueAccent : Colors.grey),
                    ),
                  ),
                ),
                if (recommande && popularite > 0)
                  Row(
                    children: [
                      const Icon(Icons.local_fire_department, size: 18, color: Colors.deepOrangeAccent),
                      const SizedBox(width: 4),
                      Text('$popularite', style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
              ],
            ),
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildInfoItem(Icons.straighten, 'Distance', distance, Colors.green),
                _buildInfoItem(Icons.terrain, 'Dénivelé', denivele, Colors.orange),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onVoirCarte,
                icon: const Icon(Icons.map),
                label: const Text('Voir la carte et le détail'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value, Color color) {
    return Row(
      children: [
        Icon(icon, color: color),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }
}
