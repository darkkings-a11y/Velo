import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../services/gpx_service.dart';

/// Ouvre le sélecteur de fichiers du téléphone, lit le GPX choisi et l'ajoute aux favoris.
/// Retourne le parcours importé, ou null si l'import a été annulé ou a échoué (un message est alors affiché).
Future<Parcours?> importerGpx(BuildContext context) async {
  final messager = ScaffoldMessenger.of(context);
  void message(String t) => messager.showSnackBar(SnackBar(content: Text(t)));

  // Fenêtre d'accueil : un grand carré à toucher pour ouvrir le répertoire du téléphone.
  final veutChoisir = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Importer votre fichier GPX', textAlign: TextAlign.center),
      content: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(ctx).pop(true),
        child: Container(
          height: 150,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.greenAccent, width: 2),
            color: Colors.white10,
          ),
          child: const Center(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.folder_open, size: 44, color: Colors.greenAccent),
                  SizedBox(height: 10),
                  Text(
                    'Touchez ici pour choisir un fichier GPX dans votre téléphone',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Annuler')),
      ],
    ),
  );
  if (veutChoisir != true) return null;

  try {
    // Tous types de fichiers : Android ne connaît pas toujours l'extension .gpx. On vérifie nous-mêmes.
    final choix = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
    if (choix == null || choix.files.isEmpty) return null;
    final f = choix.files.first;
    if (!f.name.toLowerCase().endsWith('.gpx')) {
      message('Choisis un fichier GPX (.gpx).');
      return null;
    }
    final octets = f.bytes ?? (f.path != null ? await File(f.path!).readAsBytes() : null);
    if (octets == null) {
      message('Impossible de lire ce fichier.');
      return null;
    }

    if (!context.mounted) return null;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    Parcours? p;
    try {
      final lu = await GpxService.lire(octets, nomFichier: f.name);
      await FavorisService.ajouter(lu);
      p = lu;
    } finally {
      if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
    }
    message('« ${p!.titre} » importé dans tes favoris ❤️');
    return p;
  } catch (e) {
    message(e is String ? e : "L'import a échoué : $e");
    return null;
  }
}
